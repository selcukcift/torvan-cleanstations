--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5 (Ubuntu 17.5-1.pgdg24.04+1)
-- Dumped by pg_dump version 17.5 (Ubuntu 17.5-1.pgdg24.04+1)

-- Started on 2025-06-29 15:58:12 EDT

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE IF EXISTS "torvan-db";
--
-- TOC entry 3985 (class 1262 OID 16388)
-- Name: torvan-db; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "torvan-db" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE "torvan-db" OWNER TO postgres;

\encoding SQL_ASCII
\connect -reuse-previous=on "dbname='torvan-db'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 5 (class 2615 OID 219668)
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- TOC entry 3986 (class 0 OID 0)
-- Dependencies: 5
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS '';


--
-- TOC entry 899 (class 1247 OID 219690)
-- Name: AssemblyType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."AssemblyType" AS ENUM (
    'SIMPLE',
    'COMPLEX',
    'SERVICE_PART',
    'KIT'
);


ALTER TYPE public."AssemblyType" OWNER TO postgres;

--
-- TOC entry 998 (class 1247 OID 220162)
-- Name: InventoryTransactionType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."InventoryTransactionType" AS ENUM (
    'INCOMING',
    'OUTGOING',
    'ADJUSTMENT',
    'RESERVED',
    'RELEASED'
);


ALTER TYPE public."InventoryTransactionType" OWNER TO postgres;

--
-- TOC entry 1043 (class 1247 OID 220426)
-- Name: NotificationFrequency; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."NotificationFrequency" AS ENUM (
    'IMMEDIATE',
    'HOURLY',
    'DAILY',
    'WEEKLY'
);


ALTER TYPE public."NotificationFrequency" OWNER TO postgres;

--
-- TOC entry 995 (class 1247 OID 220152)
-- Name: NotificationPriority; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."NotificationPriority" AS ENUM (
    'LOW',
    'NORMAL',
    'HIGH',
    'URGENT'
);


ALTER TYPE public."NotificationPriority" OWNER TO postgres;

--
-- TOC entry 992 (class 1247 OID 220134)
-- Name: NotificationType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."NotificationType" AS ENUM (
    'ORDER_STATUS_CHANGE',
    'TASK_ASSIGNMENT',
    'QC_APPROVAL_REQUIRED',
    'ASSEMBLY_MILESTONE',
    'SERVICE_REQUEST',
    'SYSTEM_ALERT',
    'INVENTORY_LOW',
    'DEADLINE_APPROACHING'
);


ALTER TYPE public."NotificationType" OWNER TO postgres;

--
-- TOC entry 1040 (class 1247 OID 220416)
-- Name: OrderCommentPriority; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."OrderCommentPriority" AS ENUM (
    'LOW',
    'NORMAL',
    'HIGH',
    'URGENT'
);


ALTER TYPE public."OrderCommentPriority" OWNER TO postgres;

--
-- TOC entry 926 (class 1247 OID 219807)
-- Name: OrderStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."OrderStatus" AS ENUM (
    'ORDER_CREATED',
    'SINK_BODY_EXTERNAL_PRODUCTION',
    'READY_FOR_PRE_QC',
    'READY_FOR_PRODUCTION',
    'TESTING_COMPLETE',
    'PACKAGING_COMPLETE',
    'READY_FOR_FINAL_QC',
    'READY_FOR_SHIP',
    'SHIPPED'
);


ALTER TYPE public."OrderStatus" OWNER TO postgres;

--
-- TOC entry 893 (class 1247 OID 219679)
-- Name: PartType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."PartType" AS ENUM (
    'COMPONENT',
    'MATERIAL'
);


ALTER TYPE public."PartType" OWNER TO postgres;

--
-- TOC entry 1052 (class 1247 OID 220489)
-- Name: ProductionChecklistStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ProductionChecklistStatus" AS ENUM (
    'DRAFT',
    'IN_PROGRESS',
    'COMPLETED',
    'APPROVED'
);


ALTER TYPE public."ProductionChecklistStatus" OWNER TO postgres;

--
-- TOC entry 1055 (class 1247 OID 220498)
-- Name: ProductionDocType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ProductionDocType" AS ENUM (
    'CHECKLIST_REPORT',
    'COMPLETION_CERTIFICATE',
    'QC_REPORT',
    'COMPLIANCE_PACKAGE',
    'PRODUCTION_SUMMARY'
);


ALTER TYPE public."ProductionDocType" OWNER TO postgres;

--
-- TOC entry 959 (class 1247 OID 219979)
-- Name: QcItemType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."QcItemType" AS ENUM (
    'PASS_FAIL',
    'TEXT_INPUT',
    'NUMERIC_INPUT',
    'SINGLE_SELECT',
    'MULTI_SELECT',
    'DATE_INPUT',
    'CHECKBOX'
);


ALTER TYPE public."QcItemType" OWNER TO postgres;

--
-- TOC entry 962 (class 1247 OID 219994)
-- Name: QcStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."QcStatus" AS ENUM (
    'PENDING',
    'IN_PROGRESS',
    'PASSED',
    'FAILED',
    'REQUIRES_REVIEW'
);


ALTER TYPE public."QcStatus" OWNER TO postgres;

--
-- TOC entry 977 (class 1247 OID 220071)
-- Name: ServiceOrderStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ServiceOrderStatus" AS ENUM (
    'PENDING_APPROVAL',
    'APPROVED',
    'REJECTED',
    'ORDERED',
    'RECEIVED'
);


ALTER TYPE public."ServiceOrderStatus" OWNER TO postgres;

--
-- TOC entry 896 (class 1247 OID 219684)
-- Name: Status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."Status" AS ENUM (
    'ACTIVE',
    'INACTIVE'
);


ALTER TYPE public."Status" OWNER TO postgres;

--
-- TOC entry 989 (class 1247 OID 220124)
-- Name: TaskPriority; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."TaskPriority" AS ENUM (
    'LOW',
    'MEDIUM',
    'HIGH',
    'URGENT'
);


ALTER TYPE public."TaskPriority" OWNER TO postgres;

--
-- TOC entry 986 (class 1247 OID 220113)
-- Name: TaskStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."TaskStatus" AS ENUM (
    'PENDING',
    'IN_PROGRESS',
    'COMPLETED',
    'BLOCKED',
    'CANCELLED'
);


ALTER TYPE public."TaskStatus" OWNER TO postgres;

--
-- TOC entry 920 (class 1247 OID 219784)
-- Name: UserRole; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."UserRole" AS ENUM (
    'ADMIN',
    'PRODUCTION_COORDINATOR',
    'PROCUREMENT_SPECIALIST',
    'QC_PERSON',
    'ASSEMBLER',
    'SERVICE_DEPARTMENT'
);


ALTER TYPE public."UserRole" OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 219 (class 1259 OID 219707)
-- Name: Assembly; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Assembly" (
    "AssemblyID" text NOT NULL,
    name text NOT NULL,
    type public."AssemblyType" NOT NULL,
    "categoryCode" text,
    "subcategoryCode" text,
    "workInstructionId" text,
    "qrData" text,
    "kitComponentsJson" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    revision text DEFAULT '1'::text,
    "isOrderable" boolean DEFAULT false,
    "customAttributes" jsonb
);


ALTER TABLE public."Assembly" OWNER TO postgres;

--
-- TOC entry 221 (class 1259 OID 219716)
-- Name: AssemblyComponent; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AssemblyComponent" (
    id integer NOT NULL,
    quantity integer NOT NULL,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "parentAssemblyId" text NOT NULL,
    "childPartId" text,
    "childAssemblyId" text
);


ALTER TABLE public."AssemblyComponent" OWNER TO postgres;

--
-- TOC entry 220 (class 1259 OID 219715)
-- Name: AssemblyComponent_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."AssemblyComponent_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AssemblyComponent_id_seq" OWNER TO postgres;

--
-- TOC entry 3988 (class 0 OID 0)
-- Dependencies: 220
-- Name: AssemblyComponent_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."AssemblyComponent_id_seq" OWNED BY public."AssemblyComponent".id;


--
-- TOC entry 231 (class 1259 OID 219870)
-- Name: AssociatedDocument; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AssociatedDocument" (
    id text NOT NULL,
    "docName" text NOT NULL,
    "docURL" text NOT NULL,
    "uploadedBy" text NOT NULL,
    "timestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "docType" text,
    "orderId" text NOT NULL
);


ALTER TABLE public."AssociatedDocument" OWNER TO postgres;

--
-- TOC entry 253 (class 1259 OID 220272)
-- Name: AuditLog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AuditLog" (
    id text NOT NULL,
    "userId" text,
    action text NOT NULL,
    "entityType" text NOT NULL,
    "entityId" text NOT NULL,
    "oldValues" jsonb,
    "newValues" jsonb,
    "ipAddress" text,
    "userAgent" text,
    "sessionId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."AuditLog" OWNER TO postgres;

--
-- TOC entry 227 (class 1259 OID 219837)
-- Name: BasinConfiguration; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."BasinConfiguration" (
    id text NOT NULL,
    "buildNumber" text NOT NULL,
    "basinTypeId" text NOT NULL,
    "basinSizePartNumber" text,
    "basinCount" integer DEFAULT 1 NOT NULL,
    "addonIds" text[],
    "orderId" text NOT NULL,
    "customDepth" double precision,
    "customLength" double precision,
    "customWidth" double precision
);


ALTER TABLE public."BasinConfiguration" OWNER TO postgres;

--
-- TOC entry 232 (class 1259 OID 219878)
-- Name: Bom; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Bom" (
    id text NOT NULL,
    "buildNumber" text,
    "generatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "orderId" text NOT NULL
);


ALTER TABLE public."Bom" OWNER TO postgres;

--
-- TOC entry 233 (class 1259 OID 219886)
-- Name: BomItem; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."BomItem" (
    id text NOT NULL,
    "partIdOrAssemblyId" text NOT NULL,
    name text NOT NULL,
    quantity integer NOT NULL,
    "itemType" text NOT NULL,
    category text,
    "isCustom" boolean DEFAULT false NOT NULL,
    "parentId" text,
    "bomId" text NOT NULL
);


ALTER TABLE public."BomItem" OWNER TO postgres;

--
-- TOC entry 222 (class 1259 OID 219725)
-- Name: Category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Category" (
    "categoryId" text NOT NULL,
    name text NOT NULL,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Category" OWNER TO postgres;

--
-- TOC entry 228 (class 1259 OID 219845)
-- Name: FaucetConfiguration; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."FaucetConfiguration" (
    id text NOT NULL,
    "buildNumber" text NOT NULL,
    "faucetTypeId" text NOT NULL,
    "faucetQuantity" integer DEFAULT 1 NOT NULL,
    "faucetPlacement" text,
    "orderId" text NOT NULL
);


ALTER TABLE public."FaucetConfiguration" OWNER TO postgres;

--
-- TOC entry 250 (class 1259 OID 220244)
-- Name: FileUpload; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."FileUpload" (
    id text NOT NULL,
    filename text NOT NULL,
    "originalName" text NOT NULL,
    "mimeType" text NOT NULL,
    size integer NOT NULL,
    path text NOT NULL,
    "uploadedById" text NOT NULL,
    "isPublic" boolean DEFAULT false NOT NULL,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."FileUpload" OWNER TO postgres;

--
-- TOC entry 251 (class 1259 OID 220253)
-- Name: InventoryItem; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."InventoryItem" (
    id text NOT NULL,
    "partId" text,
    "assemblyId" text,
    location text,
    "quantityOnHand" integer DEFAULT 0 NOT NULL,
    "quantityReserved" integer DEFAULT 0 NOT NULL,
    "quantityAvailable" integer DEFAULT 0 NOT NULL,
    "reorderPoint" integer,
    "maxStock" integer,
    "lastUpdated" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedById" text NOT NULL
);


ALTER TABLE public."InventoryItem" OWNER TO postgres;

--
-- TOC entry 252 (class 1259 OID 220264)
-- Name: InventoryTransaction; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."InventoryTransaction" (
    id text NOT NULL,
    "inventoryItemId" text NOT NULL,
    type public."InventoryTransactionType" NOT NULL,
    quantity integer NOT NULL,
    reason text,
    "orderId" text,
    "taskId" text,
    "performedById" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."InventoryTransaction" OWNER TO postgres;

--
-- TOC entry 235 (class 1259 OID 219902)
-- Name: Notification; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Notification" (
    id text NOT NULL,
    message text NOT NULL,
    "linkToOrder" text,
    "isRead" boolean DEFAULT false NOT NULL,
    type text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "recipientId" text NOT NULL
);


ALTER TABLE public."Notification" OWNER TO postgres;

--
-- TOC entry 256 (class 1259 OID 220448)
-- Name: NotificationPreference; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."NotificationPreference" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "notificationType" public."NotificationType" NOT NULL,
    "inAppEnabled" boolean DEFAULT true NOT NULL,
    "emailEnabled" boolean DEFAULT false NOT NULL,
    frequency public."NotificationFrequency" DEFAULT 'IMMEDIATE'::public."NotificationFrequency" NOT NULL,
    "quietHoursStart" integer,
    "quietHoursEnd" integer,
    "emailAddress" text,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."NotificationPreference" OWNER TO postgres;

--
-- TOC entry 226 (class 1259 OID 219827)
-- Name: Order; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Order" (
    id text NOT NULL,
    "poNumber" text NOT NULL,
    "buildNumbers" text[],
    "customerName" text NOT NULL,
    "projectName" text,
    "salesPerson" text NOT NULL,
    "wantDate" timestamp(3) without time zone NOT NULL,
    notes text,
    language text DEFAULT 'EN'::text NOT NULL,
    "orderStatus" public."OrderStatus" DEFAULT 'ORDER_CREATED'::public."OrderStatus" NOT NULL,
    "currentAssignee" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdById" text NOT NULL,
    "procurementData" jsonb
);


ALTER TABLE public."Order" OWNER TO postgres;

--
-- TOC entry 255 (class 1259 OID 220435)
-- Name: OrderComment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."OrderComment" (
    id text NOT NULL,
    "orderId" text NOT NULL,
    "userId" text NOT NULL,
    content text NOT NULL,
    "isInternal" boolean DEFAULT false NOT NULL,
    priority public."OrderCommentPriority" DEFAULT 'NORMAL'::public."OrderCommentPriority" NOT NULL,
    category text,
    "isResolved" boolean DEFAULT false NOT NULL,
    "resolvedAt" timestamp(3) without time zone,
    "resolvedBy" text,
    mentions text[] DEFAULT ARRAY[]::text[],
    attachments text[] DEFAULT ARRAY[]::text[],
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."OrderComment" OWNER TO postgres;

--
-- TOC entry 234 (class 1259 OID 219894)
-- Name: OrderHistoryLog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."OrderHistoryLog" (
    id text NOT NULL,
    "timestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    action text NOT NULL,
    "oldStatus" text,
    "newStatus" text,
    notes text,
    "orderId" text NOT NULL,
    "userId" text NOT NULL
);


ALTER TABLE public."OrderHistoryLog" OWNER TO postgres;

--
-- TOC entry 239 (class 1259 OID 220032)
-- Name: OrderQcItemResult; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."OrderQcItemResult" (
    id text NOT NULL,
    "orderQcResultId" text NOT NULL,
    "qcFormTemplateItemId" text NOT NULL,
    "resultValue" text,
    "isConformant" boolean,
    notes text
);


ALTER TABLE public."OrderQcItemResult" OWNER TO postgres;

--
-- TOC entry 238 (class 1259 OID 220023)
-- Name: OrderQcResult; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."OrderQcResult" (
    id text NOT NULL,
    "orderId" text NOT NULL,
    "qcFormTemplateId" text NOT NULL,
    "qcPerformedById" text NOT NULL,
    "qcTimestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "overallStatus" public."QcStatus" DEFAULT 'PENDING'::public."QcStatus" NOT NULL,
    notes text
);


ALTER TABLE public."OrderQcResult" OWNER TO postgres;

--
-- TOC entry 218 (class 1259 OID 219699)
-- Name: Part; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Part" (
    "PartID" text NOT NULL,
    name text NOT NULL,
    "manufacturerPartNumber" text,
    type public."PartType" NOT NULL,
    status public."Status" NOT NULL,
    "photoURL" text,
    "technicalDrawingURL" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    revision text DEFAULT '1'::text,
    "manufacturerName" text,
    "unitOfMeasure" text,
    "customAttributes" jsonb
);


ALTER TABLE public."Part" OWNER TO postgres;

--
-- TOC entry 257 (class 1259 OID 220509)
-- Name: ProductionChecklist; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ProductionChecklist" (
    id text NOT NULL,
    "orderId" text NOT NULL,
    "buildNumber" text,
    "jobId" text NOT NULL,
    sections jsonb NOT NULL,
    signatures jsonb NOT NULL,
    status public."ProductionChecklistStatus" DEFAULT 'DRAFT'::public."ProductionChecklistStatus" NOT NULL,
    "performedBy" text NOT NULL,
    "performedById" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "completedAt" timestamp(3) without time zone
);


ALTER TABLE public."ProductionChecklist" OWNER TO postgres;

--
-- TOC entry 260 (class 1259 OID 220537)
-- Name: ProductionDocument; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ProductionDocument" (
    id text NOT NULL,
    "orderId" text NOT NULL,
    "buildNumber" text,
    type public."ProductionDocType" NOT NULL,
    title text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    content text NOT NULL,
    format text NOT NULL,
    approved boolean DEFAULT false NOT NULL,
    "approvedBy" text,
    "approvedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ProductionDocument" OWNER TO postgres;

--
-- TOC entry 259 (class 1259 OID 220527)
-- Name: ProductionMetrics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ProductionMetrics" (
    id text NOT NULL,
    date date NOT NULL,
    "ordersStarted" integer DEFAULT 0 NOT NULL,
    "ordersCompleted" integer DEFAULT 0 NOT NULL,
    "avgCycleTime" double precision,
    "avgTaskTime" jsonb NOT NULL,
    bottlenecks jsonb NOT NULL,
    "qualityScore" double precision,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ProductionMetrics" OWNER TO postgres;

--
-- TOC entry 258 (class 1259 OID 220518)
-- Name: ProductionTask; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ProductionTask" (
    id text NOT NULL,
    "orderId" text NOT NULL,
    "buildNumber" text,
    "taskId" text NOT NULL,
    category text NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    completed boolean DEFAULT false NOT NULL,
    "actualTime" integer,
    "estimatedTime" integer NOT NULL,
    photos text[] DEFAULT ARRAY[]::text[],
    notes text,
    "startedAt" timestamp(3) without time zone,
    "completedAt" timestamp(3) without time zone,
    "completedBy" text
);


ALTER TABLE public."ProductionTask" OWNER TO postgres;

--
-- TOC entry 261 (class 1259 OID 220547)
-- Name: ProductionWorkstationSync; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ProductionWorkstationSync" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "orderId" text NOT NULL,
    "syncData" jsonb NOT NULL,
    synced boolean DEFAULT false NOT NULL,
    "syncedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ProductionWorkstationSync" OWNER TO postgres;

--
-- TOC entry 236 (class 1259 OID 220005)
-- Name: QcFormTemplate; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."QcFormTemplate" (
    id text NOT NULL,
    name text NOT NULL,
    version text DEFAULT '1.0'::text NOT NULL,
    description text,
    "isActive" boolean DEFAULT true NOT NULL,
    "appliesToProductFamily" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."QcFormTemplate" OWNER TO postgres;

--
-- TOC entry 237 (class 1259 OID 220015)
-- Name: QcFormTemplateItem; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."QcFormTemplateItem" (
    id text NOT NULL,
    "templateId" text NOT NULL,
    section text NOT NULL,
    "checklistItem" text NOT NULL,
    "itemType" public."QcItemType" NOT NULL,
    options jsonb,
    "expectedValue" text,
    "order" integer NOT NULL,
    "isRequired" boolean DEFAULT true NOT NULL,
    "applicabilityCondition" text,
    "defaultValue" text,
    "notesPrompt" text,
    "relatedAssemblyId" text,
    "relatedPartNumber" text,
    "repeatPer" text
);


ALTER TABLE public."QcFormTemplateItem" OWNER TO postgres;

--
-- TOC entry 230 (class 1259 OID 219862)
-- Name: SelectedAccessory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SelectedAccessory" (
    id text NOT NULL,
    "buildNumber" text NOT NULL,
    "assemblyId" text NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    "orderId" text NOT NULL
);


ALTER TABLE public."SelectedAccessory" OWNER TO postgres;

--
-- TOC entry 240 (class 1259 OID 220081)
-- Name: ServiceOrder; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ServiceOrder" (
    id text NOT NULL,
    "requestedById" text NOT NULL,
    "requestTimestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    status public."ServiceOrderStatus" DEFAULT 'PENDING_APPROVAL'::public."ServiceOrderStatus" NOT NULL,
    notes text,
    "procurementNotes" text,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ServiceOrder" OWNER TO postgres;

--
-- TOC entry 241 (class 1259 OID 220090)
-- Name: ServiceOrderItem; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ServiceOrderItem" (
    id text NOT NULL,
    "serviceOrderId" text NOT NULL,
    "partId" text NOT NULL,
    "quantityRequested" integer NOT NULL,
    "quantityApproved" integer,
    notes text
);


ALTER TABLE public."ServiceOrderItem" OWNER TO postgres;

--
-- TOC entry 254 (class 1259 OID 220399)
-- Name: SinkConfiguration; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SinkConfiguration" (
    id text NOT NULL,
    "buildNumber" text NOT NULL,
    "sinkModelId" text NOT NULL,
    width integer,
    length integer,
    "legsTypeId" text,
    "feetTypeId" text,
    "workflowDirection" text,
    pegboard boolean DEFAULT false NOT NULL,
    "pegboardTypeId" text,
    "pegboardColorId" text,
    "hasDrawersAndCompartments" boolean DEFAULT false NOT NULL,
    "drawersAndCompartments" text[] DEFAULT ARRAY[]::text[],
    "controlBoxId" text,
    "orderId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."SinkConfiguration" OWNER TO postgres;

--
-- TOC entry 229 (class 1259 OID 219853)
-- Name: SprayerConfiguration; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SprayerConfiguration" (
    id text NOT NULL,
    "buildNumber" text NOT NULL,
    "hasSpray" boolean DEFAULT false NOT NULL,
    "sprayerTypeIds" text[],
    "sprayerQuantity" integer DEFAULT 0 NOT NULL,
    "sprayerLocations" text[],
    "orderId" text NOT NULL
);


ALTER TABLE public."SprayerConfiguration" OWNER TO postgres;

--
-- TOC entry 223 (class 1259 OID 219733)
-- Name: Subcategory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Subcategory" (
    "subcategoryId" text NOT NULL,
    name text NOT NULL,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "categoryId" text NOT NULL
);


ALTER TABLE public."Subcategory" OWNER TO postgres;

--
-- TOC entry 249 (class 1259 OID 220234)
-- Name: SystemNotification; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SystemNotification" (
    id text NOT NULL,
    "userId" text,
    type public."NotificationType" NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    data jsonb,
    "isRead" boolean DEFAULT false NOT NULL,
    priority public."NotificationPriority" DEFAULT 'NORMAL'::public."NotificationPriority" NOT NULL,
    "expiresAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."SystemNotification" OWNER TO postgres;

--
-- TOC entry 245 (class 1259 OID 220201)
-- Name: Task; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Task" (
    id text NOT NULL,
    "orderId" text NOT NULL,
    "workInstructionId" text,
    title text NOT NULL,
    description text,
    status public."TaskStatus" DEFAULT 'PENDING'::public."TaskStatus" NOT NULL,
    priority public."TaskPriority" DEFAULT 'MEDIUM'::public."TaskPriority" NOT NULL,
    "assignedToId" text,
    "estimatedMinutes" integer,
    "actualMinutes" integer,
    "startedAt" timestamp(3) without time zone,
    "completedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Task" OWNER TO postgres;

--
-- TOC entry 246 (class 1259 OID 220211)
-- Name: TaskDependency; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."TaskDependency" (
    id text NOT NULL,
    "taskId" text NOT NULL,
    "dependsOnId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."TaskDependency" OWNER TO postgres;

--
-- TOC entry 248 (class 1259 OID 220226)
-- Name: TaskNote; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."TaskNote" (
    id text NOT NULL,
    "taskId" text NOT NULL,
    "authorId" text NOT NULL,
    content text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."TaskNote" OWNER TO postgres;

--
-- TOC entry 247 (class 1259 OID 220219)
-- Name: TaskTool; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."TaskTool" (
    id text NOT NULL,
    "taskId" text,
    "stepId" text,
    "toolId" text NOT NULL
);


ALTER TABLE public."TaskTool" OWNER TO postgres;

--
-- TOC entry 244 (class 1259 OID 220192)
-- Name: Tool; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Tool" (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    category text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Tool" OWNER TO postgres;

--
-- TOC entry 225 (class 1259 OID 219795)
-- Name: User; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."User" (
    id text NOT NULL,
    username text NOT NULL,
    email text NOT NULL,
    "passwordHash" text NOT NULL,
    "fullName" text NOT NULL,
    role public."UserRole" NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    initials text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "lastLoginAt" timestamp(3) without time zone,
    "lockedUntil" timestamp(3) without time zone,
    "loginAttempts" integer DEFAULT 0 NOT NULL,
    "assignedTaskIds" text[] DEFAULT ARRAY[]::text[],
    "clerkId" text,
    "clerkEmail" text
);


ALTER TABLE public."User" OWNER TO postgres;

--
-- TOC entry 242 (class 1259 OID 220174)
-- Name: WorkInstruction; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."WorkInstruction" (
    id text NOT NULL,
    title text NOT NULL,
    description text,
    "assemblyId" text,
    version text DEFAULT '1.0'::text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "estimatedMinutes" integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."WorkInstruction" OWNER TO postgres;

--
-- TOC entry 243 (class 1259 OID 220184)
-- Name: WorkInstructionStep; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."WorkInstructionStep" (
    id text NOT NULL,
    "workInstructionId" text NOT NULL,
    "stepNumber" integer NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    "estimatedMinutes" integer,
    images text[],
    videos text[],
    checkpoints text[],
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."WorkInstructionStep" OWNER TO postgres;

--
-- TOC entry 224 (class 1259 OID 219741)
-- Name: _SubcategoryAssemblies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."_SubcategoryAssemblies" (
    "A" text NOT NULL,
    "B" text NOT NULL
);


ALTER TABLE public."_SubcategoryAssemblies" OWNER TO postgres;

--
-- TOC entry 217 (class 1259 OID 219669)
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- TOC entry 3520 (class 2604 OID 219719)
-- Name: AssemblyComponent id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AssemblyComponent" ALTER COLUMN id SET DEFAULT nextval('public."AssemblyComponent_id_seq"'::regclass);


--
-- TOC entry 3937 (class 0 OID 219707)
-- Dependencies: 219
-- Data for Name: Assembly; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Assembly" ("AssemblyID", name, type, "categoryCode", "subcategoryCode", "workInstructionId", "qrData", "kitComponentsJson", "createdAt", "updatedAt", revision, "isOrderable", "customAttributes") FROM stdin;
\.


--
-- TOC entry 3939 (class 0 OID 219716)
-- Dependencies: 221
-- Data for Name: AssemblyComponent; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AssemblyComponent" (id, quantity, notes, "createdAt", "updatedAt", "parentAssemblyId", "childPartId", "childAssemblyId") FROM stdin;
\.


--
-- TOC entry 3949 (class 0 OID 219870)
-- Dependencies: 231
-- Data for Name: AssociatedDocument; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AssociatedDocument" (id, "docName", "docURL", "uploadedBy", "timestamp", "docType", "orderId") FROM stdin;
\.


--
-- TOC entry 3971 (class 0 OID 220272)
-- Dependencies: 253
-- Data for Name: AuditLog; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AuditLog" (id, "userId", action, "entityType", "entityId", "oldValues", "newValues", "ipAddress", "userAgent", "sessionId", "createdAt") FROM stdin;
\.


--
-- TOC entry 3945 (class 0 OID 219837)
-- Dependencies: 227
-- Data for Name: BasinConfiguration; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."BasinConfiguration" (id, "buildNumber", "basinTypeId", "basinSizePartNumber", "basinCount", "addonIds", "orderId", "customDepth", "customLength", "customWidth") FROM stdin;
cmchl4jc80002j598o3w5sl5v	2121	T2-BSN-ESK-KIT	ASSY-T2-ADW-BASIN30X20X8	1	{T2-OA-BASIN-LIGHT-ESK-KIT}	cmchl4jc40001j598ytlx7ef1	\N	\N	\N
cmchl4jc80003j598q66iynqw	2121	T2-BSN-EDR-KIT	ASSY-T2-ADW-BASIN30X20X8	1	{T2-OA-BASIN-LIGHT-EDR-KIT}	cmchl4jc40001j598ytlx7ef1	\N	\N	\N
\.


--
-- TOC entry 3950 (class 0 OID 219878)
-- Dependencies: 232
-- Data for Name: Bom; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Bom" (id, "buildNumber", "generatedAt", "orderId") FROM stdin;
\.


--
-- TOC entry 3951 (class 0 OID 219886)
-- Dependencies: 233
-- Data for Name: BomItem; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."BomItem" (id, "partIdOrAssemblyId", name, quantity, "itemType", category, "isCustom", "parentId", "bomId") FROM stdin;
\.


--
-- TOC entry 3940 (class 0 OID 219725)
-- Dependencies: 222
-- Data for Name: Category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Category" ("categoryId", name, description, "createdAt", "updatedAt") FROM stdin;
718	CONTROL BOX	Category for control box	2025-06-29 11:23:51.62	2025-06-29 11:23:51.62
719	SERVICE PARTS	Category for service parts	2025-06-29 11:23:51.641	2025-06-29 11:23:51.641
720	ACCESSORY LIST	Category for accessory list	2025-06-29 11:23:51.743	2025-06-29 11:23:51.743
721	SINK BODY	Category for sink body	2025-06-29 11:23:51.768	2025-06-29 11:23:51.768
722	BASIN	Category for basin	2025-06-29 11:23:51.778	2025-06-29 11:23:51.778
723	PEGBOARD	Category for pegboard	2025-06-29 11:23:51.788	2025-06-29 11:23:51.788
\.


--
-- TOC entry 3946 (class 0 OID 219845)
-- Dependencies: 228
-- Data for Name: FaucetConfiguration; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."FaucetConfiguration" (id, "buildNumber", "faucetTypeId", "faucetQuantity", "faucetPlacement", "orderId") FROM stdin;
cmchl4jcb0004j598tqq5knpu	2121	T2-OA-STD-FAUCET-WB-KIT	1	BASIN_1	cmchl4jc40001j598ytlx7ef1
\.


--
-- TOC entry 3968 (class 0 OID 220244)
-- Dependencies: 250
-- Data for Name: FileUpload; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."FileUpload" (id, filename, "originalName", "mimeType", size, path, "uploadedById", "isPublic", metadata, "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 3969 (class 0 OID 220253)
-- Dependencies: 251
-- Data for Name: InventoryItem; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."InventoryItem" (id, "partId", "assemblyId", location, "quantityOnHand", "quantityReserved", "quantityAvailable", "reorderPoint", "maxStock", "lastUpdated", "updatedById") FROM stdin;
\.


--
-- TOC entry 3970 (class 0 OID 220264)
-- Dependencies: 252
-- Data for Name: InventoryTransaction; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."InventoryTransaction" (id, "inventoryItemId", type, quantity, reason, "orderId", "taskId", "performedById", "createdAt") FROM stdin;
\.


--
-- TOC entry 3953 (class 0 OID 219902)
-- Dependencies: 235
-- Data for Name: Notification; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Notification" (id, message, "linkToOrder", "isRead", type, "createdAt", "recipientId") FROM stdin;
\.


--
-- TOC entry 3974 (class 0 OID 220448)
-- Dependencies: 256
-- Data for Name: NotificationPreference; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."NotificationPreference" (id, "userId", "notificationType", "inAppEnabled", "emailEnabled", frequency, "quietHoursStart", "quietHoursEnd", "emailAddress", "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 3944 (class 0 OID 219827)
-- Dependencies: 226
-- Data for Name: Order; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Order" (id, "poNumber", "buildNumbers", "customerName", "projectName", "salesPerson", "wantDate", notes, language, "orderStatus", "currentAssignee", "createdAt", "updatedAt", "createdById", "procurementData") FROM stdin;
cmchl4jc40001j598ytlx7ef1	584	{2121}	Acme 	VCx	Salesperson	2025-07-10 04:00:00	\N	FR	ORDER_CREATED	\N	2025-06-29 11:26:46.756	2025-06-29 11:26:46.756	cmchl0scb0001j58wblw915x7	\N
\.


--
-- TOC entry 3973 (class 0 OID 220435)
-- Dependencies: 255
-- Data for Name: OrderComment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."OrderComment" (id, "orderId", "userId", content, "isInternal", priority, category, "isResolved", "resolvedAt", "resolvedBy", mentions, attachments, "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 3952 (class 0 OID 219894)
-- Dependencies: 234
-- Data for Name: OrderHistoryLog; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."OrderHistoryLog" (id, "timestamp", action, "oldStatus", "newStatus", notes, "orderId", "userId") FROM stdin;
\.


--
-- TOC entry 3957 (class 0 OID 220032)
-- Dependencies: 239
-- Data for Name: OrderQcItemResult; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."OrderQcItemResult" (id, "orderQcResultId", "qcFormTemplateItemId", "resultValue", "isConformant", notes) FROM stdin;
\.


--
-- TOC entry 3956 (class 0 OID 220023)
-- Dependencies: 238
-- Data for Name: OrderQcResult; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."OrderQcResult" (id, "orderId", "qcFormTemplateId", "qcPerformedById", "qcTimestamp", "overallStatus", notes) FROM stdin;
\.


--
-- TOC entry 3936 (class 0 OID 219699)
-- Dependencies: 218
-- Data for Name: Part; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Part" ("PartID", name, "manufacturerPartNumber", type, status, "photoURL", "technicalDrawingURL", "createdAt", "updatedAt", revision, "manufacturerName", "unitOfMeasure", "customAttributes") FROM stdin;
\.


--
-- TOC entry 3975 (class 0 OID 220509)
-- Dependencies: 257
-- Data for Name: ProductionChecklist; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ProductionChecklist" (id, "orderId", "buildNumber", "jobId", sections, signatures, status, "performedBy", "performedById", "createdAt", "updatedAt", "completedAt") FROM stdin;
\.


--
-- TOC entry 3978 (class 0 OID 220537)
-- Dependencies: 260
-- Data for Name: ProductionDocument; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ProductionDocument" (id, "orderId", "buildNumber", type, title, version, content, format, approved, "approvedBy", "approvedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 3977 (class 0 OID 220527)
-- Dependencies: 259
-- Data for Name: ProductionMetrics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ProductionMetrics" (id, date, "ordersStarted", "ordersCompleted", "avgCycleTime", "avgTaskTime", bottlenecks, "qualityScore", "createdAt") FROM stdin;
\.


--
-- TOC entry 3976 (class 0 OID 220518)
-- Dependencies: 258
-- Data for Name: ProductionTask; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ProductionTask" (id, "orderId", "buildNumber", "taskId", category, title, description, completed, "actualTime", "estimatedTime", photos, notes, "startedAt", "completedAt", "completedBy") FROM stdin;
\.


--
-- TOC entry 3979 (class 0 OID 220547)
-- Dependencies: 261
-- Data for Name: ProductionWorkstationSync; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ProductionWorkstationSync" (id, "userId", "orderId", "syncData", synced, "syncedAt", "createdAt") FROM stdin;
\.


--
-- TOC entry 3954 (class 0 OID 220005)
-- Dependencies: 236
-- Data for Name: QcFormTemplate; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."QcFormTemplate" (id, name, version, description, "isActive", "appliesToProductFamily", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 3955 (class 0 OID 220015)
-- Dependencies: 237
-- Data for Name: QcFormTemplateItem; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."QcFormTemplateItem" (id, "templateId", section, "checklistItem", "itemType", options, "expectedValue", "order", "isRequired", "applicabilityCondition", "defaultValue", "notesPrompt", "relatedAssemblyId", "relatedPartNumber", "repeatPer") FROM stdin;
\.


--
-- TOC entry 3948 (class 0 OID 219862)
-- Dependencies: 230
-- Data for Name: SelectedAccessory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SelectedAccessory" (id, "buildNumber", "assemblyId", quantity, "orderId") FROM stdin;
cmchl4jcj0006j598dtq8nx9r	2121	T-OA-SSSHELF-1812	1	cmchl4jc40001j598ytlx7ef1
cmchl4jcj0007j598ge12rsz4	2121	T-OA-BINRAIL-36-KIT	1	cmchl4jc40001j598ytlx7ef1
cmchl4jcj0008j598g2v176d6	2121	T-OA-BINRAIL-48-KIT	1	cmchl4jc40001j598ytlx7ef1
\.


--
-- TOC entry 3958 (class 0 OID 220081)
-- Dependencies: 240
-- Data for Name: ServiceOrder; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ServiceOrder" (id, "requestedById", "requestTimestamp", status, notes, "procurementNotes", "updatedAt") FROM stdin;
\.


--
-- TOC entry 3959 (class 0 OID 220090)
-- Dependencies: 241
-- Data for Name: ServiceOrderItem; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ServiceOrderItem" (id, "serviceOrderId", "partId", "quantityRequested", "quantityApproved", notes) FROM stdin;
\.


--
-- TOC entry 3972 (class 0 OID 220399)
-- Dependencies: 254
-- Data for Name: SinkConfiguration; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SinkConfiguration" (id, "buildNumber", "sinkModelId", width, length, "legsTypeId", "feetTypeId", "workflowDirection", pegboard, "pegboardTypeId", "pegboardColorId", "hasDrawersAndCompartments", "drawersAndCompartments", "controlBoxId", "orderId", "createdAt", "updatedAt") FROM stdin;
cmchl4jcm0009j5981zw8gilq	2121	T2-B2	30	60	T2-DL27-KIT	ASSY-T2-LEVELING-CASTOR-475	LEFT_TO_RIGHT	t	\N	\N	f	{}	\N	cmchl4jc40001j598ytlx7ef1	2025-06-29 11:26:46.774	2025-06-29 11:26:46.774
\.


--
-- TOC entry 3947 (class 0 OID 219853)
-- Dependencies: 229
-- Data for Name: SprayerConfiguration; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SprayerConfiguration" (id, "buildNumber", "hasSpray", "sprayerTypeIds", "sprayerQuantity", "sprayerLocations", "orderId") FROM stdin;
cmchl4jcf0005j598t2bth7q7	2121	t	{T2-OA-WATERGUN-ROSETTE-KIT}	1	{RIGHT_SIDE}	cmchl4jc40001j598ytlx7ef1
\.


--
-- TOC entry 3941 (class 0 OID 219733)
-- Dependencies: 223
-- Data for Name: Subcategory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Subcategory" ("subcategoryId", name, description, "createdAt", "updatedAt", "categoryId") FROM stdin;
718.001	1 BASIN	Subcategory for 1 basin	2025-06-29 11:23:51.632	2025-06-29 11:23:51.632	718
718.002	2 BASINS	Subcategory for 2 basins	2025-06-29 11:23:51.635	2025-06-29 11:23:51.635	718
718.003	3 BASINS	Subcategory for 3 basins	2025-06-29 11:23:51.638	2025-06-29 11:23:51.638	718
719.001	WIRE BASKET BRACKET	Subcategory for wire basket bracket	2025-06-29 11:23:51.643	2025-06-29 11:23:51.643	719
719.002	ESINK TOUCHSCREEN	Subcategory for esink touchscreen	2025-06-29 11:23:51.646	2025-06-29 11:23:51.646	719
719.003	EMERGENCY BUTTON	Subcategory for emergency button	2025-06-29 11:23:51.649	2025-06-29 11:23:51.649	719
719.004	ESINK VALVE PLATE	Subcategory for esink valve plate	2025-06-29 11:23:51.652	2025-06-29 11:23:51.652	719
719.005	VALVE PLATE	Subcategory for valve plate	2025-06-29 11:23:51.654	2025-06-29 11:23:51.654	719
719.006	DI VALVE PLATE	Subcategory for di valve plate	2025-06-29 11:23:51.657	2025-06-29 11:23:51.657	719
719.007	FAUCET COMPONENT	Subcategory for faucet component	2025-06-29 11:23:51.66	2025-06-29 11:23:51.66	719
719.008	AIR/WATER GUNS	Subcategory for air/water guns	2025-06-29 11:23:51.663	2025-06-29 11:23:51.663	719
719.009	BOTTOM FILL	Subcategory for bottom fill	2025-06-29 11:23:51.665	2025-06-29 11:23:51.665	719
719.010	TEMPERATURE SENSOR	Subcategory for temperature sensor	2025-06-29 11:23:51.667	2025-06-29 11:23:51.667	719
719.011	POWER BAR	Subcategory for power bar	2025-06-29 11:23:51.67	2025-06-29 11:23:51.67	719
719.012	SINK CASTERS/LEVELING FEET	Subcategory for sink casters/leveling feet	2025-06-29 11:23:51.672	2025-06-29 11:23:51.672	719
719.013	OVERFLOW SENSOR	Subcategory for overflow sensor	2025-06-29 11:23:51.675	2025-06-29 11:23:51.675	719
719.014	LIFTER COMPONENT	Subcategory for lifter component	2025-06-29 11:23:51.678	2025-06-29 11:23:51.678	719
719.015	ACCESSORY FAUCET	Subcategory for accessory faucet	2025-06-29 11:23:51.68	2025-06-29 11:23:51.68	719
719.016	CONTROL BOX	Subcategory for control box	2025-06-29 11:23:51.683	2025-06-29 11:23:51.683	719
719.017	DRAIN HOSE COMPONENT	Subcategory for drain hose component	2025-06-29 11:23:51.686	2025-06-29 11:23:51.686	719
719.018	OTHERS	Subcategory for others	2025-06-29 11:23:51.689	2025-06-29 11:23:51.689	719
719.019	E-SINK BOARD	Subcategory for e-sink board	2025-06-29 11:23:51.692	2025-06-29 11:23:51.692	719
719.020	E-DRAIN BOARD	Subcategory for e-drain board	2025-06-29 11:23:51.695	2025-06-29 11:23:51.695	719
719.021	OVERHEAD LIGHT BOARD	Subcategory for overhead light board	2025-06-29 11:23:51.698	2025-06-29 11:23:51.698	719
719.022	BASIN LIGHT BOARD	Subcategory for basin light board	2025-06-29 11:23:51.703	2025-06-29 11:23:51.703	719
719.023	DOSING PUMP BOARD	Subcategory for dosing pump board	2025-06-29 11:23:51.709	2025-06-29 11:23:51.709	719
719.024	FLUSHING PUMP BOARD	Subcategory for flushing pump board	2025-06-29 11:23:51.715	2025-06-29 11:23:51.715	719
719.025	DOSING PUMP	Subcategory for dosing pump	2025-06-29 11:23:51.722	2025-06-29 11:23:51.722	719
719.026	DOSING PUMP & TUBE SET	Subcategory for dosing pump & tube set	2025-06-29 11:23:51.731	2025-06-29 11:23:51.731	719
719.027	UPGRADE KITS	Subcategory for upgrade kits	2025-06-29 11:23:51.738	2025-06-29 11:23:51.738	719
720.702	BASKETS, BINS & SHELVES	Subcategory for baskets, bins & shelves	2025-06-29 11:23:51.746	2025-06-29 11:23:51.746	720
720.703	HOLDERS, PLATES & HANGERS	Subcategory for holders, plates & hangers	2025-06-29 11:23:51.75	2025-06-29 11:23:51.75	720
720.704	LIGHTING ADD-ONS	Subcategory for lighting add-ons	2025-06-29 11:23:51.753	2025-06-29 11:23:51.753	720
720.705	ELECTRONIC & DIGITAL ADD-ONS	Subcategory for electronic & digital add-ons	2025-06-29 11:23:51.756	2025-06-29 11:23:51.756	720
720.706	FAUCET, OUTLET, DRAIN, SPRAYER KITS	Subcategory for faucet, outlet, drain, sprayer kits	2025-06-29 11:23:51.76	2025-06-29 11:23:51.76	720
720.707	DRAWERS & COMPARTMENTS	Subcategory for drawers & compartments	2025-06-29 11:23:51.763	2025-06-29 11:23:51.763	720
720.701	MANUAL	Subcategory for manual	2025-06-29 11:23:51.765	2025-06-29 11:23:51.765	720
721.709	SINK BODY ASSEMBLY	Subcategory for sink body assembly	2025-06-29 11:23:51.77	2025-06-29 11:23:51.77	721
721.710	SINK BODY TYPE	Subcategory for sink body type	2025-06-29 11:23:51.773	2025-06-29 11:23:51.773	721
721.711	CASTERS AND LIFTERS	Subcategory for casters and lifters	2025-06-29 11:23:51.775	2025-06-29 11:23:51.775	721
722.712	SINK BASIN SIZES	Subcategory for sink basin sizes	2025-06-29 11:23:51.78	2025-06-29 11:23:51.78	722
722.713	BASIN TYPE	Subcategory for basin type	2025-06-29 11:23:51.783	2025-06-29 11:23:51.783	722
722.714	SINK BASIN SUB-ASSEMBLY	Subcategory for sink basin sub-assembly	2025-06-29 11:23:51.785	2025-06-29 11:23:51.785	722
723.715	PEGBOARD SIZES	Subcategory for pegboard sizes	2025-06-29 11:23:51.79	2025-06-29 11:23:51.79	723
723.716	PEGBOARD CONFIGURATION	Subcategory for pegboard configuration	2025-06-29 11:23:51.793	2025-06-29 11:23:51.793	723
723.717	OVERHEAD LIGHT SUB ASSEMBLY	Subcategory for overhead light sub assembly	2025-06-29 11:23:51.795	2025-06-29 11:23:51.795	723
\.


--
-- TOC entry 3967 (class 0 OID 220234)
-- Dependencies: 249
-- Data for Name: SystemNotification; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SystemNotification" (id, "userId", type, title, message, data, "isRead", priority, "expiresAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 3963 (class 0 OID 220201)
-- Dependencies: 245
-- Data for Name: Task; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Task" (id, "orderId", "workInstructionId", title, description, status, priority, "assignedToId", "estimatedMinutes", "actualMinutes", "startedAt", "completedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 3964 (class 0 OID 220211)
-- Dependencies: 246
-- Data for Name: TaskDependency; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."TaskDependency" (id, "taskId", "dependsOnId", "createdAt") FROM stdin;
\.


--
-- TOC entry 3966 (class 0 OID 220226)
-- Dependencies: 248
-- Data for Name: TaskNote; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."TaskNote" (id, "taskId", "authorId", content, "createdAt") FROM stdin;
\.


--
-- TOC entry 3965 (class 0 OID 220219)
-- Dependencies: 247
-- Data for Name: TaskTool; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."TaskTool" (id, "taskId", "stepId", "toolId") FROM stdin;
\.


--
-- TOC entry 3962 (class 0 OID 220192)
-- Dependencies: 244
-- Data for Name: Tool; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Tool" (id, name, description, category, "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 3943 (class 0 OID 219795)
-- Dependencies: 225
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."User" (id, username, email, "passwordHash", "fullName", role, "isActive", initials, "createdAt", "updatedAt", "lastLoginAt", "lockedUntil", "loginAttempts", "assignedTaskIds", "clerkId", "clerkEmail") FROM stdin;
cmchl0sc70000j58w77bgth97	system_admin	admin@torvanmedical.com	$2b$10$K8p.uJ9J.OxK.aO9fJ.8Le8J.8J.8J.8J.8J.8J.8J.8J.8J.8J.8	System Administrator	ADMIN	t	SA	2025-06-29 11:23:51.8	2025-06-29 11:23:51.8	\N	\N	0	{}	\N	\N
cmchl0sce0002j58wu175j0iq	qc_lead	qc.lead@torvanmedical.com	$2b$10$K8p.uJ9J.OxK.aO9fJ.8Le8J.8J.8J.8J.8J.8J.8J.8J.8J.8J.8	QC Lead Inspector	QC_PERSON	t	QL	2025-06-29 11:23:51.807	2025-06-29 11:23:51.807	\N	\N	0	{}	\N	\N
cmchl0sci0003j58wxcxhwqkv	assembly_tech1	assembly1@torvanmedical.com	$2b$10$K8p.uJ9J.OxK.aO9fJ.8Le8J.8J.8J.8J.8J.8J.8J.8J.8J.8J.8	Assembly Technician 1	ASSEMBLER	t	AT1	2025-06-29 11:23:51.81	2025-06-29 11:23:51.81	\N	\N	0	{}	\N	\N
cmchl0scl0004j58wa4vxm0co	procurement_spec	procurement@torvanmedical.com	$2b$10$K8p.uJ9J.OxK.aO9fJ.8Le8J.8J.8J.8J.8J.8J.8J.8J.8J.8J.8	Procurement Specialist	PROCUREMENT_SPECIALIST	t	PS	2025-06-29 11:23:51.814	2025-06-29 11:23:51.814	\N	\N	0	{}	\N	\N
cmchl0scq0005j58wkbdxmlff	service_dept	service@torvanmedical.com	$2b$10$K8p.uJ9J.OxK.aO9fJ.8Le8J.8J.8J.8J.8J.8J.8J.8J.8J.8J.8	Service Department	SERVICE_DEPARTMENT	t	SD	2025-06-29 11:23:51.818	2025-06-29 11:23:51.818	\N	\N	0	{}	\N	\N
cmchl0scb0001j58wblw915x7	production_manager	production@torvanmedical.com	$2b$10$K8p.uJ9J.OxK.aO9fJ.8Le8J.8J.8J.8J.8J.8J.8J.8J.8J.8J.8	Production Manager	PRODUCTION_COORDINATOR	t	PM	2025-06-29 11:23:51.803	2025-06-29 11:26:46.745	\N	\N	0	{}	\N	\N
cmci2w07b0000j5xhr3ew0f8g	admin	user_2zBZBzSscTOVFHRSycWBUg5N5oK@clerk.user	CLERK_USER	admin	ASSEMBLER	t	A	2025-06-29 19:44:01.799	2025-06-29 19:44:01.799	\N	\N	0	{}	user_2zBZBzSscTOVFHRSycWBUg5N5oK	\N
\.


--
-- TOC entry 3960 (class 0 OID 220174)
-- Dependencies: 242
-- Data for Name: WorkInstruction; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."WorkInstruction" (id, title, description, "assemblyId", version, "isActive", "estimatedMinutes", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 3961 (class 0 OID 220184)
-- Dependencies: 243
-- Data for Name: WorkInstructionStep; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."WorkInstructionStep" (id, "workInstructionId", "stepNumber", title, description, "estimatedMinutes", images, videos, checkpoints, "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 3942 (class 0 OID 219741)
-- Dependencies: 224
-- Data for Name: _SubcategoryAssemblies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."_SubcategoryAssemblies" ("A", "B") FROM stdin;
\.


--
-- TOC entry 3935 (class 0 OID 219669)
-- Dependencies: 217
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
95406b9b-95fc-44d4-9351-5c4bed11c548	127e18809887f3e21c60b6c7615f01c7fbd8b5021bd0175984dfe11c0e022dc4	2025-06-29 07:23:50.66578-04	20250622000002_add_missing_part_assembly_fields	\N	\N	2025-06-29 07:23:50.661104-04	1
1793f23d-1515-46e5-a695-92787e76289d	9f8968b9fa21a2ad161ca87925545377c673f0170f755701c2ffe7f5e1c7a49b	2025-06-29 07:23:50.532452-04	20250531235152_init	\N	\N	2025-06-29 07:23:50.515723-04	1
d57b5ddd-b78e-4118-bb4f-7044f9ef17c1	d59551016ca9031fa43bd52a9b5a378bd304b3cf66f27cf57f7a4f1d175ebfc8	2025-06-29 07:23:50.544066-04	20250601015552_add_user_authentication	\N	\N	2025-06-29 07:23:50.534053-04	1
94826a29-222f-4411-8699-74364ced4ecf	1d823705094b1b28302c2b2fea8df3f33b8921fe247239f6f57c6fb879574dc4	2025-06-29 07:23:50.564494-04	20250601113956_add_order_management_models	\N	\N	2025-06-29 07:23:50.545435-04	1
d79996af-a131-4056-833b-d04b0e2377da	5c0d47c4fcd188b346399d55044d7ec314e514a338d22684c55009cce114c232	2025-06-29 07:23:50.671429-04	20250622000003_add_missing_qc_template_fields	\N	\N	2025-06-29 07:23:50.667306-04	1
0591e2a5-3ea6-4927-ae2b-f4bfba0393a9	22b4967662bdbb456d40e794aef3cccb20411392f1d897fc0eb8ee1c713f0377	2025-06-29 07:23:50.575219-04	20250602001555_add_qc_system_complete	\N	\N	2025-06-29 07:23:50.565834-04	1
9a94fb91-158b-4110-b5d7-2a3380c5ceb2	b101a5ccc26c76a5489d933e9fae8a8f638cdb4ebf29478828c66e29c816fec1	2025-06-29 07:23:50.585805-04	20250602175255_add_service_orders	\N	\N	2025-06-29 07:23:50.576679-04	1
e2d04228-29fc-49db-b102-cc4aad82b6a9	e1539d148ee616f3b4acfddffcb933a295d45d228188f601de17e4ee76568f99	2025-06-29 07:23:50.609899-04	20250605131341_add_enhanced_features	\N	\N	2025-06-29 07:23:50.587142-04	1
e915e54e-6a4a-4714-8df6-9535f859d163	b3b826e7c2e7b14c0992e16f618ec1e41bee512eff9c63d00c8a7d94bf47f611	2025-06-29 07:23:50.685125-04	20250625000000_add_production_tables	\N	\N	2025-06-29 07:23:50.672742-04	1
dd8c7b36-31ba-4ea5-a8fb-11cd06bf9861	15a16721dec934b74bb798a7f76223fd5e5541c93edc3aedea32336554b0b7c5	2025-06-29 07:23:50.615646-04	20250605135225_add_advanced_database_features	\N	\N	2025-06-29 07:23:50.611394-04	1
3dd4ed98-a4c1-49fe-94bf-9f8d873e3510	332525b83eabd5ff662760eb2f93519225cce1bcbcd767a845da743cf7306127	2025-06-29 07:23:50.622711-04	20250605195249_add_sink_configuration	\N	\N	2025-06-29 07:23:50.617345-04	1
e058f4be-7649-42db-9135-9dc301aecc33	dfc80e3fd0bf49767ba02658c3c7a74d985403ea716fa7d32548829dffc6f4be	2025-06-29 07:23:50.628534-04	20250606164501_add_custom_basin_dimensions	\N	\N	2025-06-29 07:23:50.624167-04	1
28628127-16b3-47ea-893e-b6471da48cc2	15342d12834e33b73d3e468f64e2cba10b61644f8dad1252665c1b9bbe76e96c	2025-06-29 07:23:50.638985-04	20250611000000_add_order_comments_and_notifications	\N	\N	2025-06-29 07:23:50.630193-04	1
a8c9cc70-8d7b-4281-8ba2-5d9a6e493fd3	6c7b43ebe284ab50340fca5a913a8c4756bc5aba42a4fe2608796e02043ff55f	2025-06-29 07:23:50.651991-04	20250621185248_add_procurement_data	\N	\N	2025-06-29 07:23:50.641041-04	1
e4d53e83-72a5-4a9c-a467-e6f7f8e304f0	d89f4500870b340c0b7ebff349d941f26fe00a26ec5e928baa84acdcc5c7e7a7	2025-06-29 07:23:50.659224-04	20250622000001_rename_parts_sent_to_external_production	\N	\N	2025-06-29 07:23:50.653297-04	1
\.


--
-- TOC entry 3989 (class 0 OID 0)
-- Dependencies: 220
-- Name: AssemblyComponent_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."AssemblyComponent_id_seq"', 1, false);


--
-- TOC entry 3608 (class 2606 OID 219724)
-- Name: AssemblyComponent AssemblyComponent_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AssemblyComponent"
    ADD CONSTRAINT "AssemblyComponent_pkey" PRIMARY KEY (id);


--
-- TOC entry 3606 (class 2606 OID 219714)
-- Name: Assembly Assembly_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Assembly"
    ADD CONSTRAINT "Assembly_pkey" PRIMARY KEY ("AssemblyID");


--
-- TOC entry 3636 (class 2606 OID 219877)
-- Name: AssociatedDocument AssociatedDocument_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AssociatedDocument"
    ADD CONSTRAINT "AssociatedDocument_pkey" PRIMARY KEY (id);


--
-- TOC entry 3698 (class 2606 OID 220279)
-- Name: AuditLog AuditLog_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_pkey" PRIMARY KEY (id);


--
-- TOC entry 3628 (class 2606 OID 219844)
-- Name: BasinConfiguration BasinConfiguration_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BasinConfiguration"
    ADD CONSTRAINT "BasinConfiguration_pkey" PRIMARY KEY (id);


--
-- TOC entry 3640 (class 2606 OID 219893)
-- Name: BomItem BomItem_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BomItem"
    ADD CONSTRAINT "BomItem_pkey" PRIMARY KEY (id);


--
-- TOC entry 3638 (class 2606 OID 219885)
-- Name: Bom Bom_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Bom"
    ADD CONSTRAINT "Bom_pkey" PRIMARY KEY (id);


--
-- TOC entry 3611 (class 2606 OID 219732)
-- Name: Category Category_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Category"
    ADD CONSTRAINT "Category_pkey" PRIMARY KEY ("categoryId");


--
-- TOC entry 3630 (class 2606 OID 219852)
-- Name: FaucetConfiguration FaucetConfiguration_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."FaucetConfiguration"
    ADD CONSTRAINT "FaucetConfiguration_pkey" PRIMARY KEY (id);


--
-- TOC entry 3687 (class 2606 OID 220252)
-- Name: FileUpload FileUpload_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."FileUpload"
    ADD CONSTRAINT "FileUpload_pkey" PRIMARY KEY (id);


--
-- TOC entry 3692 (class 2606 OID 220263)
-- Name: InventoryItem InventoryItem_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."InventoryItem"
    ADD CONSTRAINT "InventoryItem_pkey" PRIMARY KEY (id);


--
-- TOC entry 3695 (class 2606 OID 220271)
-- Name: InventoryTransaction InventoryTransaction_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."InventoryTransaction"
    ADD CONSTRAINT "InventoryTransaction_pkey" PRIMARY KEY (id);


--
-- TOC entry 3708 (class 2606 OID 220459)
-- Name: NotificationPreference NotificationPreference_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NotificationPreference"
    ADD CONSTRAINT "NotificationPreference_pkey" PRIMARY KEY (id);


--
-- TOC entry 3644 (class 2606 OID 219910)
-- Name: Notification Notification_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_pkey" PRIMARY KEY (id);


--
-- TOC entry 3705 (class 2606 OID 220447)
-- Name: OrderComment OrderComment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OrderComment"
    ADD CONSTRAINT "OrderComment_pkey" PRIMARY KEY (id);


--
-- TOC entry 3642 (class 2606 OID 219901)
-- Name: OrderHistoryLog OrderHistoryLog_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OrderHistoryLog"
    ADD CONSTRAINT "OrderHistoryLog_pkey" PRIMARY KEY (id);


--
-- TOC entry 3653 (class 2606 OID 220038)
-- Name: OrderQcItemResult OrderQcItemResult_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OrderQcItemResult"
    ADD CONSTRAINT "OrderQcItemResult_pkey" PRIMARY KEY (id);


--
-- TOC entry 3651 (class 2606 OID 220031)
-- Name: OrderQcResult OrderQcResult_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OrderQcResult"
    ADD CONSTRAINT "OrderQcResult_pkey" PRIMARY KEY (id);


--
-- TOC entry 3624 (class 2606 OID 219836)
-- Name: Order Order_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_pkey" PRIMARY KEY (id);


--
-- TOC entry 3603 (class 2606 OID 219706)
-- Name: Part Part_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Part"
    ADD CONSTRAINT "Part_pkey" PRIMARY KEY ("PartID");


--
-- TOC entry 3713 (class 2606 OID 220517)
-- Name: ProductionChecklist ProductionChecklist_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductionChecklist"
    ADD CONSTRAINT "ProductionChecklist_pkey" PRIMARY KEY (id);


--
-- TOC entry 3725 (class 2606 OID 220546)
-- Name: ProductionDocument ProductionDocument_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductionDocument"
    ADD CONSTRAINT "ProductionDocument_pkey" PRIMARY KEY (id);


--
-- TOC entry 3722 (class 2606 OID 220536)
-- Name: ProductionMetrics ProductionMetrics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductionMetrics"
    ADD CONSTRAINT "ProductionMetrics_pkey" PRIMARY KEY (id);


--
-- TOC entry 3718 (class 2606 OID 220526)
-- Name: ProductionTask ProductionTask_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductionTask"
    ADD CONSTRAINT "ProductionTask_pkey" PRIMARY KEY (id);


--
-- TOC entry 3727 (class 2606 OID 220555)
-- Name: ProductionWorkstationSync ProductionWorkstationSync_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductionWorkstationSync"
    ADD CONSTRAINT "ProductionWorkstationSync_pkey" PRIMARY KEY (id);


--
-- TOC entry 3648 (class 2606 OID 220022)
-- Name: QcFormTemplateItem QcFormTemplateItem_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."QcFormTemplateItem"
    ADD CONSTRAINT "QcFormTemplateItem_pkey" PRIMARY KEY (id);


--
-- TOC entry 3646 (class 2606 OID 220014)
-- Name: QcFormTemplate QcFormTemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."QcFormTemplate"
    ADD CONSTRAINT "QcFormTemplate_pkey" PRIMARY KEY (id);


--
-- TOC entry 3634 (class 2606 OID 219869)
-- Name: SelectedAccessory SelectedAccessory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SelectedAccessory"
    ADD CONSTRAINT "SelectedAccessory_pkey" PRIMARY KEY (id);


--
-- TOC entry 3657 (class 2606 OID 220096)
-- Name: ServiceOrderItem ServiceOrderItem_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ServiceOrderItem"
    ADD CONSTRAINT "ServiceOrderItem_pkey" PRIMARY KEY (id);


--
-- TOC entry 3655 (class 2606 OID 220089)
-- Name: ServiceOrder ServiceOrder_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ServiceOrder"
    ADD CONSTRAINT "ServiceOrder_pkey" PRIMARY KEY (id);


--
-- TOC entry 3701 (class 2606 OID 220409)
-- Name: SinkConfiguration SinkConfiguration_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SinkConfiguration"
    ADD CONSTRAINT "SinkConfiguration_pkey" PRIMARY KEY (id);


--
-- TOC entry 3632 (class 2606 OID 219861)
-- Name: SprayerConfiguration SprayerConfiguration_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SprayerConfiguration"
    ADD CONSTRAINT "SprayerConfiguration_pkey" PRIMARY KEY (id);


--
-- TOC entry 3613 (class 2606 OID 219740)
-- Name: Subcategory Subcategory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Subcategory"
    ADD CONSTRAINT "Subcategory_pkey" PRIMARY KEY ("subcategoryId");


--
-- TOC entry 3683 (class 2606 OID 220243)
-- Name: SystemNotification SystemNotification_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SystemNotification"
    ADD CONSTRAINT "SystemNotification_pkey" PRIMARY KEY (id);


--
-- TOC entry 3672 (class 2606 OID 220218)
-- Name: TaskDependency TaskDependency_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TaskDependency"
    ADD CONSTRAINT "TaskDependency_pkey" PRIMARY KEY (id);


--
-- TOC entry 3680 (class 2606 OID 220233)
-- Name: TaskNote TaskNote_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TaskNote"
    ADD CONSTRAINT "TaskNote_pkey" PRIMARY KEY (id);


--
-- TOC entry 3676 (class 2606 OID 220225)
-- Name: TaskTool TaskTool_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TaskTool"
    ADD CONSTRAINT "TaskTool_pkey" PRIMARY KEY (id);


--
-- TOC entry 3669 (class 2606 OID 220210)
-- Name: Task Task_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Task"
    ADD CONSTRAINT "Task_pkey" PRIMARY KEY (id);


--
-- TOC entry 3665 (class 2606 OID 220200)
-- Name: Tool Tool_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Tool"
    ADD CONSTRAINT "Tool_pkey" PRIMARY KEY (id);


--
-- TOC entry 3621 (class 2606 OID 219803)
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- TOC entry 3661 (class 2606 OID 220191)
-- Name: WorkInstructionStep WorkInstructionStep_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WorkInstructionStep"
    ADD CONSTRAINT "WorkInstructionStep_pkey" PRIMARY KEY (id);


--
-- TOC entry 3659 (class 2606 OID 220183)
-- Name: WorkInstruction WorkInstruction_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WorkInstruction"
    ADD CONSTRAINT "WorkInstruction_pkey" PRIMARY KEY (id);


--
-- TOC entry 3616 (class 2606 OID 219747)
-- Name: _SubcategoryAssemblies _SubcategoryAssemblies_AB_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."_SubcategoryAssemblies"
    ADD CONSTRAINT "_SubcategoryAssemblies_AB_pkey" PRIMARY KEY ("A", "B");


--
-- TOC entry 3600 (class 2606 OID 219677)
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- TOC entry 3604 (class 1259 OID 219749)
-- Name: Assembly_AssemblyID_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Assembly_AssemblyID_key" ON public."Assembly" USING btree ("AssemblyID");


--
-- TOC entry 3696 (class 1259 OID 220296)
-- Name: AuditLog_entityType_entityId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AuditLog_entityType_entityId_idx" ON public."AuditLog" USING btree ("entityType", "entityId");


--
-- TOC entry 3699 (class 1259 OID 220297)
-- Name: AuditLog_userId_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AuditLog_userId_createdAt_idx" ON public."AuditLog" USING btree ("userId", "createdAt");


--
-- TOC entry 3609 (class 1259 OID 219750)
-- Name: Category_categoryId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Category_categoryId_key" ON public."Category" USING btree ("categoryId");


--
-- TOC entry 3688 (class 1259 OID 220292)
-- Name: FileUpload_uploadedById_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "FileUpload_uploadedById_createdAt_idx" ON public."FileUpload" USING btree ("uploadedById", "createdAt");


--
-- TOC entry 3689 (class 1259 OID 220293)
-- Name: InventoryItem_partId_assemblyId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "InventoryItem_partId_assemblyId_idx" ON public."InventoryItem" USING btree ("partId", "assemblyId");


--
-- TOC entry 3690 (class 1259 OID 220294)
-- Name: InventoryItem_partId_assemblyId_location_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "InventoryItem_partId_assemblyId_location_key" ON public."InventoryItem" USING btree ("partId", "assemblyId", location);


--
-- TOC entry 3693 (class 1259 OID 220295)
-- Name: InventoryTransaction_inventoryItemId_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "InventoryTransaction_inventoryItemId_createdAt_idx" ON public."InventoryTransaction" USING btree ("inventoryItemId", "createdAt");


--
-- TOC entry 3709 (class 1259 OID 220464)
-- Name: NotificationPreference_userId_notificationType_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "NotificationPreference_userId_notificationType_idx" ON public."NotificationPreference" USING btree ("userId", "notificationType");


--
-- TOC entry 3710 (class 1259 OID 220463)
-- Name: NotificationPreference_userId_notificationType_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "NotificationPreference_userId_notificationType_key" ON public."NotificationPreference" USING btree ("userId", "notificationType");


--
-- TOC entry 3702 (class 1259 OID 220462)
-- Name: OrderComment_isResolved_priority_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "OrderComment_isResolved_priority_idx" ON public."OrderComment" USING btree ("isResolved", priority);


--
-- TOC entry 3703 (class 1259 OID 220460)
-- Name: OrderComment_orderId_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "OrderComment_orderId_createdAt_idx" ON public."OrderComment" USING btree ("orderId", "createdAt");


--
-- TOC entry 3706 (class 1259 OID 220461)
-- Name: OrderComment_userId_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "OrderComment_userId_createdAt_idx" ON public."OrderComment" USING btree ("userId", "createdAt");


--
-- TOC entry 3649 (class 1259 OID 220039)
-- Name: OrderQcResult_orderId_qcFormTemplateId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "OrderQcResult_orderId_qcFormTemplateId_key" ON public."OrderQcResult" USING btree ("orderId", "qcFormTemplateId");


--
-- TOC entry 3625 (class 1259 OID 219912)
-- Name: Order_poNumber_buildNumbers_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Order_poNumber_buildNumbers_key" ON public."Order" USING btree ("poNumber", "buildNumbers");


--
-- TOC entry 3626 (class 1259 OID 219911)
-- Name: Order_poNumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Order_poNumber_key" ON public."Order" USING btree ("poNumber");


--
-- TOC entry 3601 (class 1259 OID 219748)
-- Name: Part_PartID_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Part_PartID_key" ON public."Part" USING btree ("PartID");


--
-- TOC entry 3711 (class 1259 OID 220556)
-- Name: ProductionChecklist_orderId_buildNumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ProductionChecklist_orderId_buildNumber_key" ON public."ProductionChecklist" USING btree ("orderId", "buildNumber");


--
-- TOC entry 3714 (class 1259 OID 220557)
-- Name: ProductionChecklist_status_orderId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductionChecklist_status_orderId_idx" ON public."ProductionChecklist" USING btree (status, "orderId");


--
-- TOC entry 3723 (class 1259 OID 220562)
-- Name: ProductionDocument_orderId_type_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductionDocument_orderId_type_idx" ON public."ProductionDocument" USING btree ("orderId", type);


--
-- TOC entry 3719 (class 1259 OID 220561)
-- Name: ProductionMetrics_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductionMetrics_date_idx" ON public."ProductionMetrics" USING btree (date);


--
-- TOC entry 3720 (class 1259 OID 220560)
-- Name: ProductionMetrics_date_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ProductionMetrics_date_key" ON public."ProductionMetrics" USING btree (date);


--
-- TOC entry 3715 (class 1259 OID 220559)
-- Name: ProductionTask_completed_orderId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductionTask_completed_orderId_idx" ON public."ProductionTask" USING btree (completed, "orderId");


--
-- TOC entry 3716 (class 1259 OID 220558)
-- Name: ProductionTask_orderId_category_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductionTask_orderId_category_idx" ON public."ProductionTask" USING btree ("orderId", category);


--
-- TOC entry 3728 (class 1259 OID 220563)
-- Name: ProductionWorkstationSync_synced_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProductionWorkstationSync_synced_userId_idx" ON public."ProductionWorkstationSync" USING btree (synced, "userId");


--
-- TOC entry 3614 (class 1259 OID 219751)
-- Name: Subcategory_subcategoryId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Subcategory_subcategoryId_key" ON public."Subcategory" USING btree ("subcategoryId");


--
-- TOC entry 3684 (class 1259 OID 220291)
-- Name: SystemNotification_type_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SystemNotification_type_createdAt_idx" ON public."SystemNotification" USING btree (type, "createdAt");


--
-- TOC entry 3685 (class 1259 OID 220290)
-- Name: SystemNotification_userId_isRead_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "SystemNotification_userId_isRead_idx" ON public."SystemNotification" USING btree ("userId", "isRead");


--
-- TOC entry 3673 (class 1259 OID 220285)
-- Name: TaskDependency_taskId_dependsOnId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "TaskDependency_taskId_dependsOnId_idx" ON public."TaskDependency" USING btree ("taskId", "dependsOnId");


--
-- TOC entry 3674 (class 1259 OID 220286)
-- Name: TaskDependency_taskId_dependsOnId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "TaskDependency_taskId_dependsOnId_key" ON public."TaskDependency" USING btree ("taskId", "dependsOnId");


--
-- TOC entry 3681 (class 1259 OID 220289)
-- Name: TaskNote_taskId_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "TaskNote_taskId_createdAt_idx" ON public."TaskNote" USING btree ("taskId", "createdAt");


--
-- TOC entry 3677 (class 1259 OID 220288)
-- Name: TaskTool_stepId_toolId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "TaskTool_stepId_toolId_key" ON public."TaskTool" USING btree ("stepId", "toolId");


--
-- TOC entry 3678 (class 1259 OID 220287)
-- Name: TaskTool_taskId_toolId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "TaskTool_taskId_toolId_key" ON public."TaskTool" USING btree ("taskId", "toolId");


--
-- TOC entry 3666 (class 1259 OID 220283)
-- Name: Task_assignedToId_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Task_assignedToId_status_idx" ON public."Task" USING btree ("assignedToId", status);


--
-- TOC entry 3667 (class 1259 OID 220282)
-- Name: Task_orderId_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Task_orderId_status_idx" ON public."Task" USING btree ("orderId", status);


--
-- TOC entry 3670 (class 1259 OID 220284)
-- Name: Task_status_priority_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Task_status_priority_idx" ON public."Task" USING btree (status, priority);


--
-- TOC entry 3618 (class 1259 OID 220605)
-- Name: User_clerkId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User_clerkId_key" ON public."User" USING btree ("clerkId");


--
-- TOC entry 3619 (class 1259 OID 219805)
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- TOC entry 3622 (class 1259 OID 219804)
-- Name: User_username_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User_username_key" ON public."User" USING btree (username);


--
-- TOC entry 3662 (class 1259 OID 220280)
-- Name: WorkInstructionStep_workInstructionId_stepNumber_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "WorkInstructionStep_workInstructionId_stepNumber_idx" ON public."WorkInstructionStep" USING btree ("workInstructionId", "stepNumber");


--
-- TOC entry 3663 (class 1259 OID 220281)
-- Name: WorkInstructionStep_workInstructionId_stepNumber_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "WorkInstructionStep_workInstructionId_stepNumber_key" ON public."WorkInstructionStep" USING btree ("workInstructionId", "stepNumber");


--
-- TOC entry 3617 (class 1259 OID 219752)
-- Name: _SubcategoryAssemblies_B_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "_SubcategoryAssemblies_B_index" ON public."_SubcategoryAssemblies" USING btree ("B");


--
-- TOC entry 3729 (class 2606 OID 219763)
-- Name: AssemblyComponent AssemblyComponent_childAssemblyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AssemblyComponent"
    ADD CONSTRAINT "AssemblyComponent_childAssemblyId_fkey" FOREIGN KEY ("childAssemblyId") REFERENCES public."Assembly"("AssemblyID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 3730 (class 2606 OID 219758)
-- Name: AssemblyComponent AssemblyComponent_childPartId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AssemblyComponent"
    ADD CONSTRAINT "AssemblyComponent_childPartId_fkey" FOREIGN KEY ("childPartId") REFERENCES public."Part"("PartID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 3731 (class 2606 OID 219753)
-- Name: AssemblyComponent AssemblyComponent_parentAssemblyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AssemblyComponent"
    ADD CONSTRAINT "AssemblyComponent_parentAssemblyId_fkey" FOREIGN KEY ("parentAssemblyId") REFERENCES public."Assembly"("AssemblyID") ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 3740 (class 2606 OID 219938)
-- Name: AssociatedDocument AssociatedDocument_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AssociatedDocument"
    ADD CONSTRAINT "AssociatedDocument_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public."Order"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 3776 (class 2606 OID 220393)
-- Name: AuditLog AuditLog_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 3736 (class 2606 OID 219918)
-- Name: BasinConfiguration BasinConfiguration_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BasinConfiguration"
    ADD CONSTRAINT "BasinConfiguration_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public."Order"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 3742 (class 2606 OID 219948)
-- Name: BomItem BomItem_bomId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BomItem"
    ADD CONSTRAINT "BomItem_bomId_fkey" FOREIGN KEY ("bomId") REFERENCES public."Bom"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 3743 (class 2606 OID 219953)
-- Name: BomItem BomItem_parentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BomItem"
    ADD CONSTRAINT "BomItem_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES public."BomItem"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 3741 (class 2606 OID 219943)
-- Name: Bom Bom_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Bom"
    ADD CONSTRAINT "Bom_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public."Order"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 3737 (class 2606 OID 219923)
-- Name: FaucetConfiguration FaucetConfiguration_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."FaucetConfiguration"
    ADD CONSTRAINT "FaucetConfiguration_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public."Order"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 3769 (class 2606 OID 220358)
-- Name: FileUpload FileUpload_uploadedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."FileUpload"
    ADD CONSTRAINT "FileUpload_uploadedById_fkey" FOREIGN KEY ("uploadedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 3770 (class 2606 OID 220363)
-- Name: InventoryItem InventoryItem_partId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."InventoryItem"
    ADD CONSTRAINT "InventoryItem_partId_fkey" FOREIGN KEY ("partId") REFERENCES public."Part"("PartID") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3771 (class 2606 OID 220368)
-- Name: InventoryItem InventoryItem_updatedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."InventoryItem"
    ADD CONSTRAINT "InventoryItem_updatedById_fkey" FOREIGN KEY ("updatedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 3772 (class 2606 OID 220373)
-- Name: InventoryTransaction InventoryTransaction_inventoryItemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."InventoryTransaction"
    ADD CONSTRAINT "InventoryTransaction_inventoryItemId_fkey" FOREIGN KEY ("inventoryItemId") REFERENCES public."InventoryItem"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3773 (class 2606 OID 220378)
-- Name: InventoryTransaction InventoryTransaction_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."InventoryTransaction"
    ADD CONSTRAINT "InventoryTransaction_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public."Order"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 3774 (class 2606 OID 220388)
-- Name: InventoryTransaction InventoryTransaction_performedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."InventoryTransaction"
    ADD CONSTRAINT "InventoryTransaction_performedById_fkey" FOREIGN KEY ("performedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 3775 (class 2606 OID 220383)
-- Name: InventoryTransaction InventoryTransaction_taskId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."InventoryTransaction"
    ADD CONSTRAINT "InventoryTransaction_taskId_fkey" FOREIGN KEY ("taskId") REFERENCES public."Task"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 3781 (class 2606 OID 220480)
-- Name: NotificationPreference NotificationPreference_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NotificationPreference"
    ADD CONSTRAINT "NotificationPreference_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3746 (class 2606 OID 219973)
-- Name: Notification Notification_linkToOrder_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_linkToOrder_fkey" FOREIGN KEY ("linkToOrder") REFERENCES public."Order"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 3747 (class 2606 OID 219968)
-- Name: Notification Notification_recipientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_recipientId_fkey" FOREIGN KEY ("recipientId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 3778 (class 2606 OID 220465)
-- Name: OrderComment OrderComment_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OrderComment"
    ADD CONSTRAINT "OrderComment_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public."Order"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3779 (class 2606 OID 220475)
-- Name: OrderComment OrderComment_resolvedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OrderComment"
    ADD CONSTRAINT "OrderComment_resolvedBy_fkey" FOREIGN KEY ("resolvedBy") REFERENCES public."User"(id) ON UPDATE CASCADE;


--
-- TOC entry 3780 (class 2606 OID 220470)
-- Name: OrderComment OrderComment_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OrderComment"
    ADD CONSTRAINT "OrderComment_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE;


--
-- TOC entry 3744 (class 2606 OID 219958)
-- Name: OrderHistoryLog OrderHistoryLog_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OrderHistoryLog"
    ADD CONSTRAINT "OrderHistoryLog_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public."Order"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 3745 (class 2606 OID 219963)
-- Name: OrderHistoryLog OrderHistoryLog_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OrderHistoryLog"
    ADD CONSTRAINT "OrderHistoryLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 3752 (class 2606 OID 220060)
-- Name: OrderQcItemResult OrderQcItemResult_orderQcResultId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OrderQcItemResult"
    ADD CONSTRAINT "OrderQcItemResult_orderQcResultId_fkey" FOREIGN KEY ("orderQcResultId") REFERENCES public."OrderQcResult"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3753 (class 2606 OID 220065)
-- Name: OrderQcItemResult OrderQcItemResult_qcFormTemplateItemId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OrderQcItemResult"
    ADD CONSTRAINT "OrderQcItemResult_qcFormTemplateItemId_fkey" FOREIGN KEY ("qcFormTemplateItemId") REFERENCES public."QcFormTemplateItem"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 3749 (class 2606 OID 220045)
-- Name: OrderQcResult OrderQcResult_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OrderQcResult"
    ADD CONSTRAINT "OrderQcResult_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public."Order"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 3750 (class 2606 OID 220050)
-- Name: OrderQcResult OrderQcResult_qcFormTemplateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OrderQcResult"
    ADD CONSTRAINT "OrderQcResult_qcFormTemplateId_fkey" FOREIGN KEY ("qcFormTemplateId") REFERENCES public."QcFormTemplate"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 3751 (class 2606 OID 220055)
-- Name: OrderQcResult OrderQcResult_qcPerformedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."OrderQcResult"
    ADD CONSTRAINT "OrderQcResult_qcPerformedById_fkey" FOREIGN KEY ("qcPerformedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 3735 (class 2606 OID 219913)
-- Name: Order Order_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Order"
    ADD CONSTRAINT "Order_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 3782 (class 2606 OID 220564)
-- Name: ProductionChecklist ProductionChecklist_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductionChecklist"
    ADD CONSTRAINT "ProductionChecklist_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public."Order"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 3783 (class 2606 OID 220569)
-- Name: ProductionChecklist ProductionChecklist_performedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductionChecklist"
    ADD CONSTRAINT "ProductionChecklist_performedById_fkey" FOREIGN KEY ("performedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 3786 (class 2606 OID 220589)
-- Name: ProductionDocument ProductionDocument_approvedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductionDocument"
    ADD CONSTRAINT "ProductionDocument_approvedBy_fkey" FOREIGN KEY ("approvedBy") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 3787 (class 2606 OID 220584)
-- Name: ProductionDocument ProductionDocument_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductionDocument"
    ADD CONSTRAINT "ProductionDocument_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public."Order"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 3784 (class 2606 OID 220579)
-- Name: ProductionTask ProductionTask_completedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductionTask"
    ADD CONSTRAINT "ProductionTask_completedBy_fkey" FOREIGN KEY ("completedBy") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 3785 (class 2606 OID 220574)
-- Name: ProductionTask ProductionTask_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductionTask"
    ADD CONSTRAINT "ProductionTask_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public."Order"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 3788 (class 2606 OID 220599)
-- Name: ProductionWorkstationSync ProductionWorkstationSync_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductionWorkstationSync"
    ADD CONSTRAINT "ProductionWorkstationSync_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public."Order"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 3789 (class 2606 OID 220594)
-- Name: ProductionWorkstationSync ProductionWorkstationSync_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProductionWorkstationSync"
    ADD CONSTRAINT "ProductionWorkstationSync_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 3748 (class 2606 OID 220040)
-- Name: QcFormTemplateItem QcFormTemplateItem_templateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."QcFormTemplateItem"
    ADD CONSTRAINT "QcFormTemplateItem_templateId_fkey" FOREIGN KEY ("templateId") REFERENCES public."QcFormTemplate"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3739 (class 2606 OID 219933)
-- Name: SelectedAccessory SelectedAccessory_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SelectedAccessory"
    ADD CONSTRAINT "SelectedAccessory_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public."Order"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 3755 (class 2606 OID 220107)
-- Name: ServiceOrderItem ServiceOrderItem_partId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ServiceOrderItem"
    ADD CONSTRAINT "ServiceOrderItem_partId_fkey" FOREIGN KEY ("partId") REFERENCES public."Part"("PartID") ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 3756 (class 2606 OID 220102)
-- Name: ServiceOrderItem ServiceOrderItem_serviceOrderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ServiceOrderItem"
    ADD CONSTRAINT "ServiceOrderItem_serviceOrderId_fkey" FOREIGN KEY ("serviceOrderId") REFERENCES public."ServiceOrder"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3754 (class 2606 OID 220097)
-- Name: ServiceOrder ServiceOrder_requestedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ServiceOrder"
    ADD CONSTRAINT "ServiceOrder_requestedById_fkey" FOREIGN KEY ("requestedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 3777 (class 2606 OID 220410)
-- Name: SinkConfiguration SinkConfiguration_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SinkConfiguration"
    ADD CONSTRAINT "SinkConfiguration_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public."Order"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 3738 (class 2606 OID 219928)
-- Name: SprayerConfiguration SprayerConfiguration_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SprayerConfiguration"
    ADD CONSTRAINT "SprayerConfiguration_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public."Order"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 3732 (class 2606 OID 219768)
-- Name: Subcategory Subcategory_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Subcategory"
    ADD CONSTRAINT "Subcategory_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public."Category"("categoryId") ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 3768 (class 2606 OID 220353)
-- Name: SystemNotification SystemNotification_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SystemNotification"
    ADD CONSTRAINT "SystemNotification_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3761 (class 2606 OID 220323)
-- Name: TaskDependency TaskDependency_dependsOnId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TaskDependency"
    ADD CONSTRAINT "TaskDependency_dependsOnId_fkey" FOREIGN KEY ("dependsOnId") REFERENCES public."Task"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3762 (class 2606 OID 220318)
-- Name: TaskDependency TaskDependency_taskId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TaskDependency"
    ADD CONSTRAINT "TaskDependency_taskId_fkey" FOREIGN KEY ("taskId") REFERENCES public."Task"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3766 (class 2606 OID 220348)
-- Name: TaskNote TaskNote_authorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TaskNote"
    ADD CONSTRAINT "TaskNote_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3767 (class 2606 OID 220343)
-- Name: TaskNote TaskNote_taskId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TaskNote"
    ADD CONSTRAINT "TaskNote_taskId_fkey" FOREIGN KEY ("taskId") REFERENCES public."Task"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3763 (class 2606 OID 220333)
-- Name: TaskTool TaskTool_stepId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TaskTool"
    ADD CONSTRAINT "TaskTool_stepId_fkey" FOREIGN KEY ("stepId") REFERENCES public."WorkInstructionStep"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3764 (class 2606 OID 220328)
-- Name: TaskTool TaskTool_taskId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TaskTool"
    ADD CONSTRAINT "TaskTool_taskId_fkey" FOREIGN KEY ("taskId") REFERENCES public."Task"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3765 (class 2606 OID 220338)
-- Name: TaskTool TaskTool_toolId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TaskTool"
    ADD CONSTRAINT "TaskTool_toolId_fkey" FOREIGN KEY ("toolId") REFERENCES public."Tool"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3758 (class 2606 OID 220313)
-- Name: Task Task_assignedToId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Task"
    ADD CONSTRAINT "Task_assignedToId_fkey" FOREIGN KEY ("assignedToId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 3759 (class 2606 OID 220303)
-- Name: Task Task_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Task"
    ADD CONSTRAINT "Task_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public."Order"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3760 (class 2606 OID 220308)
-- Name: Task Task_workInstructionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Task"
    ADD CONSTRAINT "Task_workInstructionId_fkey" FOREIGN KEY ("workInstructionId") REFERENCES public."WorkInstruction"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 3757 (class 2606 OID 220298)
-- Name: WorkInstructionStep WorkInstructionStep_workInstructionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WorkInstructionStep"
    ADD CONSTRAINT "WorkInstructionStep_workInstructionId_fkey" FOREIGN KEY ("workInstructionId") REFERENCES public."WorkInstruction"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3733 (class 2606 OID 219773)
-- Name: _SubcategoryAssemblies _SubcategoryAssemblies_A_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."_SubcategoryAssemblies"
    ADD CONSTRAINT "_SubcategoryAssemblies_A_fkey" FOREIGN KEY ("A") REFERENCES public."Assembly"("AssemblyID") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3734 (class 2606 OID 219778)
-- Name: _SubcategoryAssemblies _SubcategoryAssemblies_B_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."_SubcategoryAssemblies"
    ADD CONSTRAINT "_SubcategoryAssemblies_B_fkey" FOREIGN KEY ("B") REFERENCES public."Subcategory"("subcategoryId") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3987 (class 0 OID 0)
-- Dependencies: 5
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


-- Completed on 2025-06-29 15:58:12 EDT

--
-- PostgreSQL database dump complete
--

